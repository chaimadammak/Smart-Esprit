#ifndef FUNCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include <gtk/gtk.h>
typedef struct
{
int jour ;
int mois  ;
int annee;
}date;

typedef struct 
{
char nomproduit[15];
char type[15];
char quantite[15];
char id[20];
char prixStock[20];
char ntel[20]; 
int etat;
date d;

}stock;

void ajouter(stock s);
void modifier(stock s,char id1[20]);
void supprimer(stock s, char id1[20]);
int chercher (GtkWidget *liste,char id1[20]);
int verifier(char id1[20]);
void Stock_rompue();
void afficher(GtkWidget *liste);

#endif // FUNCTION_H_INCLUDED
