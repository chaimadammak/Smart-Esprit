#include <gtk/gtk.h>


void
on_button11_ajouter_clicked            (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_radiobutton1_stock_non_rompue_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_stock_rompue_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_etes_vous_sur_de_vouloir_supprimer_le_menu_s__lection___toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on___tes_vous_sur_de_vouloir_effectuer_ces_modification_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_button13_afficher_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
