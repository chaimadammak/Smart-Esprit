#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "stock.h"


int etat;
int m=1;
void
on_button11_ajouter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
stock s;
GtkWidget *nomproduit, *id, *prixStock, *ntel;

GtkWidget *comboboxentry2_type;

GtkWidget *jour,*mois,*annee, *quantite;
GtkWidget *entry9_nomproduit,*entry10_prixStock,*entry17_ntel,*entry14_id;


jour=lookup_widget(objet,"spinbutton3");
mois=lookup_widget(objet,"spinbutton4");
annee=lookup_widget(objet,"spinbutton5");


nomproduit=lookup_widget(objet,"entry9_nomproduit");
prixStock=lookup_widget(objet,"entry10_prixStock");
comboboxentry2_type=lookup_widget(objet,"comboboxentry2_type");
id=lookup_widget(objet,"entry14_id");
ntel=lookup_widget(objet,"entry17_ntel");
quantite=lookup_widget(objet,"spinbutton1");


s.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
s.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
s.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));

strcpy(s.nomproduit,gtk_entry_get_text(GTK_ENTRY(nomproduit)));
strcpy(s.prixStock,gtk_entry_get_text(GTK_ENTRY(prixStock)));
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry2_type)));
strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(s.ntel,gtk_entry_get_text(GTK_ENTRY(ntel)));
s.etat=etat;

ajouter(s);


}



void
on_radiobutton1_stock_non_rompue_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
etat=0;
 }
}


void
on_radiobutton_stock_rompue_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
etat=1;

}

}


void 
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *recherche;
GtkWidget *treeview2;
GtkWidget *treeview6;
GtkWidget *outputMsg;
int v;
char text[200];
char id1[20];
window1=lookup_widget(objet,"window1");
treeview6=lookup_widget(window1,"treeview2");
recherche=lookup_widget(objet,"entry15_id");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(recherche)));

v=verifier(id1);

switch(v)
{
case 0:
{
strcpy (text,"stock introuvable");
outputMsg=lookup_widget(objet,("label67_message"));
gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
break;
case 1:
{
chercher(treeview6, id1);
strcpy (text,"stock trouvable");
outputMsg=lookup_widget(objet,("label67_message"));
gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
	
break;
break;


}
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
stock s;
char id1[20],id2[20];
char s1[20] , s2[20],s3[20] ,s4[15],s5[15],s6;
char msg [50];
int test=0;
FILE *f,*g ;
input1= lookup_widget (objet, "entry20_id");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("stock.txt","r");
g=fopen("dechets.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s %d", &s1,&s2,&s3,&id2,&s4,&s5,&s6) == 6)

    if (strcmp (id2, id1) != 0) 
      fprintf (g, "%s %s %s %s %s %s %d\n", s1,s2,s3,id2,s4,s5,s6);
  fclose(f);
  fclose(g);
f=fopen("stock.txt","w");
g=fopen("dechets.txt","r");
  while (fscanf (g, "%s %s %s %s %s %s %d ", &s1,&s2,&s3,&id2,&s4,&s5,&s6) == 6) 
      fprintf (f,"%s %s %s %s %s %s %d\n", s1,s2,s3,id2,s4,s5,s6);
 fclose (f);
 fclose(g);
}






void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
stock s;


GtkWidget *comboboxentry3_type;
char id1[20];
int t,m;
char message[20];
GtkWidget *input1, *input2, *input3, *input4, *input5 ,*input6,*message5;

input1=lookup_widget(objet,"entry11_nomproduit");
input2=lookup_widget(objet,"comboboxentry3_type");
input3=lookup_widget(objet,"spinbutton2");
input4=lookup_widget(objet,"entry16_id");
input5=lookup_widget(objet,"entry12_prixStock");
input6=lookup_widget(objet,"entry18_ntel");




message5=lookup_widget(objet,"label68_message3");


strcpy(s.nomproduit,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(s.prixStock,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(s.ntel,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
s.etat=etat;




gtk_label_set_text(GTK_LABEL(message5),"Modification done");
}





void
on_checkbutton1_etes_vous_sur_de_vouloir_supprimer_le_menu_s__lection___toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on___tes_vous_sur_de_vouloir_effectuer_ces_modification_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
m=2;
}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}



void
on_button13_afficher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *window1;
GtkWidget *treeview2;

window1=lookup_widget(objet,"window1");
treeview2=lookup_widget(window1,"treeview2");
afficher(treeview2);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nomproduit;
gchar *prixStock;
gchar *type;
gchar *id;
gchar *ntel; 
gchar *quantite;
gint *etat;
stock s;
char id1[20];
date d;


GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&nomproduit,1,&type,2,&quantite,3,&id,4,&prixStock,5,&ntel,6,&etat,-1);

strcpy(s.nomproduit,nomproduit);
strcpy(s.prixStock,prixStock);
strcpy(s.type,type);
strcpy(s.id,id);
strcpy(s.ntel,ntel);
strcpy(s.quantite,quantite);
s.etat=etat;
//supprimer(s,id1);
afficher(treeview);
}
}




