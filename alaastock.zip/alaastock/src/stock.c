#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "stock.h"
#include <gtk/gtk.h>
enum
{
ENOMPRODUIT,
ETYPE,
EID,
EPRIXSTOCK,
ENTEL,
EQUANTITE,
EJOUR,
EMOIS,
EANNEE,
COLUMNS
};
void ajouter(stock s)
{
    FILE* f = NULL;
    f=fopen("stock.txt","a");
    if (f!=NULL)
    {
    
    fprintf(f,"%s %s %s %s %s %s %d %d %d %d\n",s.nomproduit,s.prixStock,s.type,s.id,s.ntel,s.quantite,s.etat,s.d.jour,s.d.mois,s.d.annee);
       
    fclose(f);

    }
    else
    {
      printf("impossible d'ouvrir le fichier\n");
    }
}

void afficher(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter ;
GtkListStore *store ;


char nomproduit[15];
char type[15];
char quantite[15];
char id[20];
char prixStock[20];
char ntel[20];
int etat;
int jour , mois , annee ;

store = NULL ;
FILE *f ;
store=gtk_tree_view_get_model(liste);
if(store == NULL)
{
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nomproduit",renderer , "text" , ENOMPRODUIT, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prixStock",renderer , "text" , EPRIXSTOCK, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer , "text" , ETYPE, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("id",renderer , "text" , EID, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("ntel",renderer , "text" , ENTEL, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ; 

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite",renderer , "text" , EQUANTITE, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("jour",renderer , "text" , EJOUR, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("mois",renderer , "text" , EMOIS, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("annee",renderer , "text" , EANNEE, NULL );
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column) ;

store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("stock.txt", "r") ;
if(f==NULL)
{
return;
}
else
{
f=fopen("stock.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %d %d %d %d\n",nomproduit,prixStock,type,id,ntel,quantite,&etat,&jour,&mois,&annee) != EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOMPRODUIT,nomproduit,EPRIXSTOCK,prixStock,ETYPE,type,EID,id,ENTEL,ntel,EQUANTITE,quantite,EJOUR,jour,EMOIS,mois,EANNEE,annee,-1);
}
fclose(f) ;
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

int chercher(GtkWidget *liste,char id1[20])
{
    FILE* f;
    stock s;
    f=fopen("stock.txt","r");
    if(f!=NULL)
    {

    while(fscanf(f,"%s %s %s %s %s %s %d %d %d %d\n",s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,&s.etat,&s.d.jour,&s.d.mois,&s.d.annee)!=EOF)
    {
        if(strcmp(s.id,id1)==0)
        {
            printf("%s %s %s %s %s %s %d %d %d %d\n",s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,s.etat,s.d.jour,s.d.mois,s.d.annee);
         }
         }   

    fclose(f);
    
         }
         }

int verifier(char id1[20])
{
stock s;
FILE *f = NULL;
f=fopen("stock.txt","r");
if (f!=NULL)
{
while(fscanf(f,"s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,&s.etat,&s.d.jour,&s.d.mois,&s.d.annee")!=EOF)
{
if (strcmp(s.id,id1)==0)
{
return 1;

}
fclose(f);
return 0;
}
}
}

void modifier(stock s,char id1[20])
{
stock newstock;	
FILE*f;
FILE*f1;
f=fopen("stock.txt","r");
f1=fopen("dechets.txt","w");

if ((f!=NULL) && (f1!=NULL))
    {
while(fscanf(f,"%s %s %s %s %s %s %d %d %d %d\n",s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,&s.etat,&s.d.jour,&s.d.mois,&s.d.annee)!=EOF)
    {
if(strcmp(s.id,newstock.id)==0)
    {
fprintf(f1,"%s %s %s %s %s %s %d %d %d %d\n",s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,s.etat,s.d.jour,s.d.mois,s.d.annee);
    }
else
    {

fprintf(f1,"%s %s %s %s %s %s %d %d %d %d\n",newstock.nomproduit,newstock.type,newstock.quantite,newstock.id,newstock.prixStock,newstock.ntel,newstock.etat,newstock.d.jour,newstock.d.mois,newstock.d.annee);
    }
    }
fclose(f);
fclose(f1);

remove("stock.txt");
rename("dechets.txt","stock.txt");
return 1;
}      
}

void supprimer(stock s, char id1[20])
{
FILE *f = NULL;
FILE *f1 = NULL;

f=fopen("stock.txt","r");
f1=fopen("dechets.txt","w");
if (f!=NULL)
{

while(fscanf(f,"%s %s %s %s %s %s %d\n",s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,&s.etat)!=EOF)
{

if (strcmp(s.id,id1)!=0){
fprintf(f1,"%s %s %s %s %s %s %d\n",s.nomproduit,s.type,s.quantite,s.id,s.prixStock,s.ntel,s.etat);
}
}
}
fclose(f);
fclose(f1);
remove("stock.txt");
rename("dechets.txt" , "stock.txt");
return 1 ;
}
