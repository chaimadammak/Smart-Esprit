#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"
int x1;
int x2;




///////////////////////////////////////////////////////
void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowAjout ;
windowAjout=create_fenetre_ajouter();
gtk_widget_show(windowAjout);


}

////////////////////////////////////////

void
on_button7_add_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation r;
GtkWidget *fenetre_ajouter;


GtkWidget *input1,*input2;
char texte1[100];
char texte2[100];





input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
if(x1==1)
strcpy(texte1,"Nutrition");
else 
strcpy(texte1,"Hebergement");

if(x2==1)
strcpy(texte2,"Validé");
else
strcpy(texte2,"non_validé");


strcpy(r.msg,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.type,texte1);
strcpy(r.etat,texte2);
strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input2)));


ajouter_reclamation( r);

fenetre_ajouter=lookup_widget(button,"fenetre_ajouter");
gtk_widget_destroy(fenetre_ajouter);
}


void
on_radiobutton3_valide_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x2=1;}
}


void
on_radiobutton2_heb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x1=2;}
}


void
on_radiobutton1_nut_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x1=1;}
}


void
on_radiobutton4_n_valide_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x2=2;}
}

///////////////////////AFFICHER////////////////////////////////////////



void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAfficher;
GtkWidget *treeview1;

windowAfficher=lookup_widget(button,"fenetre_afficher");
windowAfficher=create_fenetre_afficher();

gtk_widget_show(windowAfficher);

treeview1=lookup_widget(windowAfficher,"treeview1");

afficher_reclamation(treeview1);
}





void on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* msg;
	gchar* type;
	gchar* etat;
	gchar* id;
	reclamation r;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		//obtenir des valeurs de la ligne selectionnée

		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&msg,1,&type,2,&etat,3,&id,-1);
		//copie
		strcpy(r.msg,msg);
		strcpy(r.type,type);
		strcpy(r.etat,etat);
		strcpy(r.id,id);
		//appel de la fct suppression
		supprimer_reclamation(r);
		//mise a jour
		afficher_reclamation(treeview);
	}
}

////////////////////////////////////////////////////////
void
on_button1_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
}

///////////////////////////////SUPPRIMER/////////////////////////////////

void
on_button3_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAfficher;
GtkWidget *treeview1;

windowAfficher=lookup_widget(button,"fenetre_afficher");
windowAfficher=create_fenetre_afficher();

gtk_widget_show(windowAfficher);

treeview1=lookup_widget(windowAfficher,"treeview1");

afficher_reclamation(treeview1);
}



//////////////////////////RECHERCHER//////////////////////////////////

void
on_button2_recherche_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowRecherche;
windowRecherche=create_fenetre_rechercher1 ();
gtk_widget_show(windowRecherche);

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechercher1;
GtkWidget *windowRechercher2;
GtkWidget *treeview2;
GtkWidget *input1;
reclamation r;
FILE *f1;
FILE *f2;

int d=0,i;
char c,msg[100],type[100],etat[100],id[100],ident[100];
reclamation rec[100];


input1=lookup_widget(button,"entry3");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(input1)));

// rechercher
f1=fopen("reclamation.txt","r+");
while((c=fgetc(f1)) !=EOF )
 {
  if(c=='\n')
  d++;
 }
fclose(f1);

f1=fopen("reclamation.txt","r");
for (i=0;i<d;i++)
{
fscanf(f1,"%s %s %s %s\n",rec[i].msg,rec[i].type,rec[i].etat,&rec[i].id);
if (strcmp(ident,rec[i].id)==0)
{
strcpy(id,rec[i].id);
strcpy(msg,rec[i].msg);
strcpy(type,rec[i].type);
strcpy(etat,rec[i].etat);
}
}
if (strcmp(id,ident)==0)
	{
	strcpy(r.id,id);
	strcpy(r.msg,msg);
	strcpy(r.type,type);
	strcpy(r.etat,etat);

	ajouter_recherche(r);
	}
else
	{
	strcpy(r.id,"introuvable!");
	strcpy(r.msg,"introuvable!");
	strcpy(r.type,"introuvable!");
	strcpy(r.etat,"introuvable!");
	
	ajouter_recherche(r);

	
	}
	

windowRechercher2=lookup_widget(button,"fenetre_rechercher2");
windowRechercher2=create_fenetre_rechercher2();

gtk_widget_show(windowRechercher2);

treeview2=lookup_widget(windowRechercher2,"treeview2");

chercher_reclamation(treeview2);


fenetre_rechercher1=lookup_widget(button,"fenetre_rechercher1");
gtk_widget_destroy(fenetre_rechercher1);
}






void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* msg;
	gchar* type;
	gchar* etat;
	gchar* id;
	reclamation r;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model,&iter,path))
	{
		//obtenir des valeurs de la ligne selectionnée

		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&msg,1,&type,2,&etat,3,&id,-1);
		//copie
		strcpy(r.msg,msg);
		strcpy(r.type,type);
		strcpy(r.etat,etat);
		strcpy(r.id,id);
		//appel de la fct suppression
		supprimer_reclamation(r);
		//mise a jour
		chercher_reclamation(treeview);

	}
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_rechercher2;
fenetre_rechercher2=lookup_widget(button,"fenetre_rechercher2");
gtk_widget_destroy(fenetre_rechercher2);
}



///////////////////////MODIFIER /////////////////////////////////










void
on_button4_modifier_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *output;
GtkWidget *input1,*input2,*combobox1,*combobox2;
FILE *f;

reclamation r;
int d=0,i;
char c,msg[100],type[100],etat[100],id[100],ident[100],message[100];
char text1[100],text2[100];
reclamation rec[100];

/// collect donné ////

input1=lookup_widget(objet_graphique,"entry4");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(input1)));

input2=lookup_widget(objet_graphique,"entry5");
strcpy(message,gtk_entry_get_text(GTK_ENTRY(input2)));

combobox1=lookup_widget(objet_graphique,"combobox1");
if(strcmp("Nutrition",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))))

	strcpy(text1,"Nutrition");
else
	strcpy(text1,"Hebergement");


combobox2=lookup_widget(objet_graphique,"combobox2");

if(strcmp("Validé",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2))))

	strcpy(text2,"Validé");
else
	strcpy(text2,"non_Validé");

strcpy(r.msg,message);
strcpy(r.type,text1);
strcpy(r.etat,text2);
strcpy(r.id,ident);



output=lookup_widget(objet_graphique,"label26");

/// rechercher////

f=fopen("reclamation.txt","r+");
while((c=fgetc(f)) !=EOF )
 {
  if(c=='\n')
  d++;
 }
fclose(f);

f=fopen("reclamation.txt","r");
for (i=0;i<d;i++)
{
fscanf(f,"%s %s %s %s\n",rec[i].msg,rec[i].type,rec[i].etat,rec[i].id);
if (strcmp(ident,rec[i].id)==0)
{
strcpy(id,rec[i].id);
}
}

if  (strcmp(id,ident)==0)
	{
	modifier_reclamation(r) ;// modifier 
	gtk_label_set_text(GTK_LABEL(output),"Modification terminer !");
	}





else
	
	gtk_label_set_text(GTK_LABEL(output),"Identifiant introuvable !");
	

}









void
on_button6_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowModifier;
windowModifier=create_fenetre_modifier ();
gtk_widget_show(windowModifier);
}


////////////////////////////PLUS RECLAMEE//////////////////////////

void
on_button5_plus_reclamee_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

/*
char type[100];
char text[100];
;

GtkWidget *output;


output=lookup_widget(objet_graphique,"label29");

char type=leplusreclamer();
printf("%s", "hhh");
strcpy(text,"bfbf");



fenetre_plusreclame=create_fenetre_plusreclame ();
gtk_widget_show(fenetre_plusreclame);

gtk_label_set_text(GTK_LABEL(output),text);*/


GtkWidget *fenetre_plusreclame;

fenetre_plusreclame=create_fenetre_plusreclame ();
gtk_widget_show(fenetre_plusreclame);


}


void
on_lpr_clicked                         (GtkWidget         *objet_graphique,
                                        gpointer         user_data)
{
char type[100];
//char text[100];
;

GtkWidget *output;
GtkWidget *fenetre_plusreclame;

output=lookup_widget(objet_graphique,"label29");

leplusreclamer(type);
printf("%s", type);
//strcpy(text,type);




gtk_label_set_text(GTK_LABEL(output),type);
}


void
on_button4_instagram_mondher_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.instagram.com/");
}


void
on_button5_Facebook_mondher_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox https://www.facebook.com/");
}

