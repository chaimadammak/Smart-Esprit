#ifndef PROB_PAR_H_INCLUDED
#define PROB_PAR_H_INCLUDED
#include <gtk/gtk.h>
typedef struct identifiant
{
char nom[20];
char prenom[20];
char ID[20];
int niveau;
char bloc[20];
char num[20];

char sexe[20];

/**
int nbre;
int nb1;
int nb2;
int nb3;
int nb4;
int nb5;
**/
}identifiant;



void ajouter_etudiant(identifiant c);
void afficher_resultat(GtkWidget *liste );
int verif(char nom[]);
void actu(GtkWidget *liste );
void modifier(char ID[],identifiant c1);
void supprimer_etudiant(char ID[]);
void chercher(char nom[],identifiant c);
void afficher_cherche(GtkWidget *liste );
void afficher_etudiant();
int controle(char ch[]);


//int i;
//void nombre_etudiant(identifiant c);

#endif
