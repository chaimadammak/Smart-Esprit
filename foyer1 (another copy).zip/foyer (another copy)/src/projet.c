#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "projet.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "support.h"



enum
{
ENOM,
EPRENOM,
EID,
ENIVEAU,
EBLOC,
ENUM,
ESEXE,
COLUMNS
};

enum
{
ENOM1,
EPRENOM1,
EID1,
ENIVEAU1,
EBLOC1,
ENUM1,
ESEXE1,
COLUMNS1
};



//////////////////////////////////////


void ajouter_etudiant(identifiant c)
{
FILE* f=NULL;
f=fopen("etudiant.txt","a+");
if(f!=NULL)
fprintf(f,"%s %s %s %d %s %s %s\n",c.nom,c.prenom,c.ID,c.niveau,c.bloc,c.num,c.sexe);
fclose(f); 
}




//////////////////////////////////////////////////////////////////



void afficher_resultat(GtkWidget *liste )
{	identifiant c;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *f ;

	
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);


if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("ID",renderer,"text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("niveau",renderer,"text",ENIVEAU,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("bloc",renderer,"text",EBLOC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("num",renderer,"text",ENUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	
	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);	

	f=fopen("etudiant.txt","r");
	if(f==NULL)
	
		printf("erreur ");
	
	else
	{
f=fopen("etudiant.txt","a+");
	while((fscanf(f, "%s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe))!=EOF)
	{
	
		
		gtk_list_store_append (store,&iter);
		gtk_list_store_set (store,&iter,ENOM,c.nom,EPRENOM,c.prenom,EID,c.ID,ENIVEAU,c.niveau,EBLOC,c.bloc,ENUM,c.num,ESEXE,c.sexe,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
}

////////////////////////////////////////////////

void actu(GtkWidget *liste )

{

identifiant c;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *f;
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	
	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("ID",renderer,"text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("niveau",renderer,"text",ENIVEAU,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("bloc",renderer,"text",EBLOC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("num",renderer,"text",ENUM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);	
gtk_list_store_append(store,&iter);

gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
//g_object_unref(store);
}

///////////////////////////////////////////////////


void modifier (char ID[],identifiant c1)
{ 
identifiant c;
FILE *f=NULL;
FILE*g=NULL;
f=fopen("etudiant.txt","r");
g=fopen("test.txt","w");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe )==7)

if (strcmp(c1.ID,c.ID)==0)
{
fprintf(g,"%s %s %s %d %s %s %s\n",c1.nom,c1.prenom,c.ID,c.niveau,c1.bloc,c1.num,c.sexe) ;
}
else
{       
fprintf(g,"%s %s %s %d %s %s %s\n",c.nom,c.prenom,c.ID,c.niveau,c.bloc,c.num,c.sexe);
}
}

fclose(f);
fclose(g);

remove("etudiant.txt");
rename("test.txt","etudiant.txt");





}







///////////////////////////////////////////////////////


void chercher(char nom[],identifiant c){
FILE*f=NULL;
FILE* g=NULL;
//char nom[20];
remove("nom.txt");
f=fopen("etudiant.txt","r");
g=fopen("nom.txt","a+"); 
if(f!=NULL)
{
while(fscanf(f," %s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe)!=EOF){
if(strcmp(nom,c.nom)==0)
fprintf(g,"%s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,c.niveau,c.bloc,c.num,c.sexe);
}
}
fclose(g);
fclose(f);
}







//////////////////////////////////////////////


void afficher_cherche(GtkWidget *liste )
{	
	identifiant c;
	GtkCellRenderer *renderer1;
	GtkTreeViewColumn *column1;
	GtkTreeIter iter1;
	GtkListStore *store1;
	FILE *f ;

	store1=NULL;
	
	store1=gtk_tree_view_get_model(liste);

	if(store1==NULL)
	{
	
	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("nom",renderer1,"text",ENOM1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);
	

	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("prenom",renderer1,"text",EPRENOM1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

	
	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("ID",renderer1,"text",EID1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

	
	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("niveau",renderer1,"text",ENIVEAU1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);
	

	
	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("bloc",renderer1,"text",EBLOC1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("num",renderer1,"text",ENUM1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


	renderer1=gtk_cell_renderer_text_new ();
	column1=gtk_tree_view_column_new_with_attributes ("sexe",renderer1,"text",ESEXE1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


	store1=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);	

	f=fopen("nom.txt","r");
	if(f==NULL)
	
		printf("erreur ");
	
	else
	{
	f=fopen("nom.txt","a+");
	while((fscanf(f, "%s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe))!=EOF)
	{
		gtk_list_store_append (store1,&iter1);
		gtk_list_store_set (store1,&iter1,ENOM1,c.nom,EPRENOM1,c.prenom,EID1,c.ID,ENIVEAU1,c.niveau,EBLOC1,c.bloc,ENUM1,c.num,ESEXE1,c.sexe,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store1));
	g_object_unref(store1);
	
}
}
} 	
	
	
//////////////////////////////////////


void supprimer_etudiant(char ID[])
{

FILE*f=NULL;
FILE*g=NULL;
identifiant c;
f=fopen("etudiant.txt","r");
g=fopen("test.txt","a+");

while(fscanf(f,"%s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe)!=EOF)
{ if(strcmp(ID,c.ID)!=0)
fprintf(g,"%s %s %s %d %s %s %s\n",c.nom,c.prenom,c.ID,c.niveau,c.bloc,c.num,c.sexe);

}

fclose(f);
fclose(g);
remove("etudiant.txt");
rename("test.txt","etudiant.txt");
}


/////////////////////////////////////////////////////////////





void afficher_etudiant()
{
FILE *f;
identifiant c;
f=fopen("etudiant.txt","r");
if (f!=NULL)
{
while((fscanf(f,"%s %s %s %d %s %s %s\n",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe)!=EOF))
{
printf(" nom %s | prenom %s | ID %s | niveau %d | bloc %s | numero %s | sexe %s /n ",c.nom,c.prenom,c.ID,c.niveau,c.bloc,c.num,c.sexe );
}
}
fclose(f);
}



/////////////////////////////////////////////////////////////


/**

void nombre_etudiant(identifiant c) {

int nb1;
int nb2;
int nb3;
int nb4;
int nb5;

nb1=0;
nb2=0;
nb3=0;
nb4=0;
nb5=0;


FILE* f;
f=fopen("etudiant.txt","r");
printf("donner votre niveau");
scanf("%d",c.niveau);
if (c.niveau==1)
nb1++;
else
if (c.niveau==2)
nb2++;
else
if (c.niveau==3)
nb3++;
else
if (c.niveau==4)
nb4++;
else
if (c.niveau==5)
nb5++;
else

fprintf(f,"le nbre des etudiants de chaque niveau: %d %d %d %d %d\n",c.nb1,c.nb2,c.nb3,c.nb4,c.nb5);
fclose(f); 
 
}
**/

//////////////////////////////// 




/////////////////////////////////////////verif/////////////////////////////////


int verif(char nom[])
{
    int test=0;
    FILE*f=NULL;
    identifiant c ;
    f=fopen("etudiant.txt","r");
    while ((fscanf(f," %s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe )!=EOF)&&(test==0)){
            if(strcmp(nom,c.nom)==0)
            {
                test=1;
            }

}
return test;

}
    

///////////////////////////////////////////////////////


int controle(char ch[])
{
int len,i=0,f,test=0;
len = strlen(ch);
for (i=0;i<len;i++)
{
if(isdigit(ch[i])==0)
{
test=1;
}
}
return test;
}




