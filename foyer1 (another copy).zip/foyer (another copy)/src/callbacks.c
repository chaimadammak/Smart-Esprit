#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "projet.h"

int x=2;
int s=0,test=0,t=0,y2=0;


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=1;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=2;
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
s=1;
}

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

identifiant c;
char text[50]="";
char text2[50]="";
char text3[50]="";
FILE *f=NULL;
GtkWidget *input1,*input2,*input3,*input4,*spin,*combobox1,*output,*output3;
GtkWidget *ajout_user;


ajout_user=lookup_widget(button,"window1");

input1 = lookup_widget(button,"entry30");
input2 = lookup_widget(button,"entry31");
input3 = lookup_widget(button,"entry32");
input4 = lookup_widget(button,"entry33");


spin=lookup_widget(button,"spinbutton6");

combobox1=lookup_widget(button,"combobox1");

strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.ID,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.num,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(c.bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));


c.niveau=(gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin)));
if (s==1)
	strcpy(c.sexe,"femme");
else
	strcpy(c.sexe,"homme");


t=verif(c.nom);

if(t==0){
sprintf(text,"ajout avec succés");
output=lookup_widget(button , "label190");
gtk_label_set_text(GTK_LABEL(output),text);


/**
if (s==0)
	strcpy(c.sexe,"male");
if (s==1)
	strcpy(c.sexe,"femalle");
if ((test==0)||(t==0)){
sprintf(text,"erreur detecte");




else
{
ajouter_etudiant(c);
sprintf(text,"fait avec succés");
}
**/

ajouter_etudiant(c);


sprintf(text,"");
output3=lookup_widget(button, "label1932");
gtk_label_set_text(GTK_LABEL(output3),text);
}
else
{
sprintf(text2,"erreur d'ajout");
output=lookup_widget(button,"label190");
gtk_label_set_text(GTK_LABEL(output),text2);

}
if (t==1)
{
sprintf(text3,"l'identifiant existe déja ! ");
output3=lookup_widget(button, "label1932");
gtk_label_set_text(GTK_LABEL(output3),text3);
}
}







void
on_treeview13_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

identifiant c;
	GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* ID;
	gint* niveau;
	gchar* bloc;
	gchar* num;
	gchar* sexe;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	//obtention de valeur de la ligne selectionne
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,nom,1,prenom,2,ID,3,&niveau,4,bloc,5,num,6,sexe);
	strcpy(c.nom,nom);
	strcpy(c.prenom,prenom);
	strcpy(c.ID,ID);
	c.niveau=niveau;
	strcpy(c.bloc,bloc);
	strcpy(c.num,num);
	strcpy(c.sexe,sexe);
	supprimer_etudiant(ID);
	//appelle a la fonction ajout
	afficher_resultat(treeview);
	}


}


void
on_button45_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button44_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* output;
identifiant c;
char text[50]="";
GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;

GtkWidget *p=lookup_widget(button,"treeview13");


gchar *ID;


selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
if(gtk_tree_selection_get_selected(selection,&model,&iter))
{
gtk_tree_model_get(model,&iter,2,&ID,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);



supprimer_etudiant(ID);
sprintf(text,"supprimé avec succées");
output=lookup_widget(button, "label1927");
gtk_label_set_text(GTK_LABEL(output),text);
}
else
{
sprintf(text,"erreur de suppresion");
output=lookup_widget(button, "label1927");
gtk_label_set_text(GTK_LABEL(output),text);
}

}


void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *A, *B, *C, *D, *E , *G;

int v=-1;
char text[50]="";

/*GtkWidget* ID2;

GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget *treeview13;
GtkWidget* output;*/

//gchar *ID;
char IDN[20];
char votrenom[50];
char votreprenom[50];
char votrenum[50];
char votrebloc[50];
char votreniveau[50];

char ID[20];
char IDD[20];
char nom[20];
char prenom[20];
int niveau;
char bloc[20];
char num[20];
char sexe[20];
//int y3;
identifiant c;
identifiant c1;



A = lookup_widget(button, "entry94");
B = lookup_widget(button, "entry95");
C = lookup_widget(button, "entry97");
D = lookup_widget(button, "entry98");
E = lookup_widget(button, "entry99");
G = lookup_widget(button, "entry96");

FILE * F;
F=fopen("etudiant.txt","r");
strcpy(c1.nom,gtk_entry_get_text(GTK_ENTRY(A)));
strcpy(c1.prenom,gtk_entry_get_text(GTK_ENTRY(B)));
strcpy(c1.num,gtk_entry_get_text(GTK_ENTRY(C)));
strcpy(c1.bloc,gtk_entry_get_text(GTK_ENTRY(D)));
//strcpy(c1.niveau,gtk_entry_get_text(GTK_ENTRY(E)));
strcpy(c1.ID,gtk_entry_get_text(GTK_ENTRY(G)));


if (F!=NULL)
{
while (fscanf(F,"%s %s %s %d %s %s %s",c.nom,c.prenom,c.ID,&c.niveau,c.bloc,c.num,c.sexe )!=EOF){
if (strcmp(c1.ID,c.ID) ==0)
{
v=1;
}
}
fclose (F);
}

//strcpy(ID2,gtk_entry_get_text(GTK_ENTRY(ID)));


modifier(ID, c1);


/*sprintf(text,"modification faite");
output=lookup_widget(button, "label1925");
gtk_label_set_text(GTK_LABEL(output),text);*/


}

/*
else
{
sprintf(text,"erreur");
output=lookup_widget(button, "label1925");
gtk_label_set_text(GTK_LABEL(output),text);
}*/




void
on_button43_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *identif;
GtkWidget *treeview13;
treeview13=lookup_widget(button,"treeview13");
afficher_resultat(treeview13);

}


void on_button1_recherche_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview14;
GtkWidget *nom;
char nom1[20];
identifiant c;
FILE *f;
nom=  lookup_widget(button, "entry93");
strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
chercher(nom1,c);
treeview14=lookup_widget(button,"treeview14");
afficher_cherche(treeview14);

}



void
on_button1_actualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *identif,*c1;
GtkWidget *treeview13;
c1=lookup_widget(button,"identif");
identif=create_surface_foyer();

gtk_widget_show(identif);

gtk_widget_hide(c1);

treeview13=lookup_widget(identif,"treeview13");

afficher_resultat(treeview13);
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y2=1;
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
system ("firefox https://www.instagram.com/");
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
system ("firefox https://www.facebook.com/");
}

