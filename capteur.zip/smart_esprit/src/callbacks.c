#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "dashbord.h"

int etat,metat,t;

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

char text[100];
char text1[100];
capt c;

GtkWidget *refe,*marque,*prix,*valmin,*valmax,*output,*output1;

GtkWidget *combobox_type,*vrefe;
GtkWidget *jour,*mois,*annee;

jour=lookup_widget(button,"jour");
mois=lookup_widget(button,"mois");
annee=lookup_widget(button,"annee");
combobox_type=lookup_widget(button,"combobox_type");
refe=lookup_widget(button,"entry_reference");
marque=lookup_widget(button,"entry_marque");
prix=lookup_widget(button,"entry_prix");
valmin=lookup_widget(button,"entry_valmin");
valmax=lookup_widget(button,"entry_valmax");





c.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
c.date.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
c.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(c.refe,gtk_entry_get_text(GTK_ENTRY(refe)));
strcpy(c.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
strcpy(c.valmin,gtk_entry_get_text(GTK_ENTRY(valmin)));
strcpy(c.valmax,gtk_entry_get_text(GTK_ENTRY(valmax)));
strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_type)));
c.etat=etat;

t=verifier(c.refe);

if (t==0)
{
sprintf(text,"ajout avec succes");
output=lookup_widget(button,"label_succes");
gtk_label_set_text(GTK_LABEL(output),text);
ajouter(c);


}
if (t==1) 
{
sprintf(text1,"capteur existe deja");
output1=lookup_widget(button,"label_existe");
gtk_label_set_text(GTK_LABEL(output1),text1);
}

}


void
on_radiobutton_hs_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
etat=0;

}

}


void
on_radiobutton_es_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
etat=1;

}

}



void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}


void
on_button_afficher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *capteur,*fixed_dashbord;
GtkWidget *treeview1;

capteur=lookup_widget(objet,"capteur");

fixed_dashbord=lookup_widget(objet,"fixed_dashbord");
treeview1=lookup_widget(capteur,"treeview1");

  treeview1 = gtk_tree_view_new ();
  gtk_widget_show (treeview1);
  gtk_fixed_put (GTK_FIXED (fixed_dashbord), treeview1, 104, 120);
  gtk_widget_set_size_request (treeview1, 552, 368);
  gtk_tree_view_set_rules_hint (GTK_TREE_VIEW (treeview1), TRUE);


afficher_capteur(treeview1);

}



void
on_supprimer_cap_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{	
	GtkTreeModel *model;
	GtkTreeSelection *selection;
	GtkTreeIter iter;
	GtkWidget *treeview1;
	gchar *refe;

	treeview1=lookup_widget(button,"treeview1");

	selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview1));
	if(gtk_tree_selection_get_selected(selection,&model,&iter))
	{
	gtk_tree_model_get(model,&iter,0,&refe,-1);
	gtk_list_store_remove(GTK_LIST_STORE(model),&iter);

	supprimer(refe);
}

}


void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

capt rc;
GtkWidget *input1;
GtkWidget *capteur;
GtkWidget *treeview2;
GtkWidget *combobox_rech,*fixed5;

combobox_rech=lookup_widget(button,"combobox_rech");
treeview2=lookup_widget(button,"treeview2");
strcpy(rc.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_rech)));
 
chercher_capteur(rc);

fixed5=lookup_widget(button,"fixed5");
treeview2=lookup_widget(button,"treeview2");

treeview2 = gtk_tree_view_new ();
gtk_widget_show (treeview2);

gtk_fixed_put (GTK_FIXED (fixed5), treeview2, 208, 168);
gtk_widget_set_size_request (treeview2, 576, 384);


afficher_capteur_chercher(treeview2);



}



void
on_button_actuliser_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *capteur,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"capteur");
capteur=create_capteur();

gtk_widget_show(capteur);

gtk_widget_hide(w1);

treeview1=lookup_widget(capteur,"treeview1");
afficher_capteur(treeview1);
}





void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_rech_modif_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{



}


void
on_button_modif_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

capt m;
GtkWidget *mrefe,*mmarque,*prix,*mvalmin,*mvalmax;


mrefe=lookup_widget(button,"entry_rech_modif");

mmarque=lookup_widget(button,"entry_modif_marque");
mvalmin=lookup_widget(button,"entry_modif_vmin");
mvalmax=lookup_widget(button,"entry_modif_vmax");


strcpy(m.refe,gtk_entry_get_text(GTK_ENTRY(mrefe)));

strcpy(m.marque,gtk_entry_get_text(GTK_ENTRY(mmarque)));
strcpy(m.valmin,gtk_entry_get_text(GTK_ENTRY(mvalmin)));
strcpy(m.valmax,gtk_entry_get_text(GTK_ENTRY(mvalmax)));

m.etat=metat;


modifier(m);

}


void
on_radiobutton_modif_hs_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
metat=0;

}

}


void
on_radiobutton_modif_es_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{
metat=1;

}

}

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}
void
on_button_aff_defc_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview3;
GtkWidget *capteur;

capteur=lookup_widget(button,"capteur");
treeview3=lookup_widget(button,"treeview3");

capteur_defectueux(treeview3);

}




