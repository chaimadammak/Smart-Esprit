
#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
int etage;
int jour;
int heure;
float temperature;


}defectueux; 

void capteur_defectueux(GtkWidget *liste);





#endif //  FONCTION_H_INCLUDED
