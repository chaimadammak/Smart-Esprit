#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "support.h"
#include "dashbord.h"


enum
{	
	ETAGE,
	TJOUR,
        HEURE,
        TEMPERATURE,
	COLUMNS1 
};
void capteur_defectueux(GtkWidget *liste)

{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
	
int etage;
int jour;
int heure;
float temperature;

defectueux d;

store=NULL;

FILE *f2;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("etage", renderer, "text",ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",TJOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("heure", renderer, "text",HEURE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("temperature", renderer, "text",TEMPERATURE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste), column);

}
	
store=gtk_list_store_new(COLUMNS1,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_FLOAT);
f2 = fopen("Dashbord.txt","r");
if(f2 == NULL)
{
return;
}

else
{
f2 = fopen("Dashbord.txt","a+");

while(fscanf(f2,"%d %d %d %f",&d.etage,&d.jour,&d.heure,&d.temperature)!=EOF)
{
if ((temperature<10) || (temperature>30))                						  
{
gtk_list_store_append(store, &iter);						  			 	
gtk_list_store_set (store,&iter,ETAGE,d.etage,TJOUR,d.jour,HEURE,d.heure,TEMPERATURE,d.temperature,-1);		
}
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
