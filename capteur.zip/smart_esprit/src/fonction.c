
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "support.h"


enum
{
 	REFE,
 	MARQUE,
 	TYPE,
 	PRIX,
 	VALMIN,
 	VALMAX,
 	ETAT,
	JOUR,
	MOIS,
	ANNEE,
 	COLUMNS
};



void supprimer(char srefe[])
{
capt c;
    FILE *f=NULL;
    FILE *ft=NULL;
    f=fopen("capteurs.txt","r");
    ft=fopen("sup.txt","a+");
    if ((f!=NULL)&&(ft!=NULL))
    {
     while(fscanf(f,"%s %s %s %s %d %d %d %s %s %d",c.refe,c.marque,c.type,c.prix,&c.date.j,&c.date.m,&c.date.a,c.valmin,c.valmax,&c.etat)!=EOF)
    {
        if ( strcmp(c.refe,srefe)!=0)
        {
       
	fprintf(ft,"%s %s %s %s %d %d %d %s %s %d\n",c.refe,c.marque,c.type,c.prix,c.date.j,c.date.m,c.date.a,c.valmin,c.valmax,c.etat);
        }

    }
        fclose(f);
        fclose(ft);
        remove("capteurs.txt");
        rename("sup.txt","capteurs.txt");
        }
        else
    {
      printf("impossible d'ouvrir le fichier");
    }
    }
void ajouter(capt c)
{


    FILE *f;
    f=fopen("capteurs.txt","a");
    if (f!=NULL)
    {
       

    fprintf(f,"%s %s %s %s %d %d %d %s %s %d\n",c.refe,c.marque,c.type,c.prix,c.date.j,c.date.m,c.date.a,c.valmin,c.valmax,c.etat);
        fclose(f);

    }

}
void afficher_capteur(GtkWidget *liste)
{
capt c;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char refe[30];
char marque[30];
char type[30];
char prix[30];
char valmin[30];
char valmax[30];
int etat;
int jour;
int mois;
int annee;

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("refe",renderer, "text",REFE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("marque",renderer, "text",MARQUE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer, "text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer, "text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("valmin",renderer, "text",VALMIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("valmax",renderer, "text",VALMAX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer, "text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer, "text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer, "text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer, "text",ETAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

f=fopen("capteurs.txt","r");
if(f==NULL)
{
return;
}
else

{f=fopen("capteurs.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %d",c.refe,c.marque,c.type,c.prix,&c.date.j,&c.date.m,&c.date.a,c.valmin,c.valmax,&c.etat)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,REFE,c.refe,MARQUE,c.marque,TYPE,c.type,PRIX,c.prix,JOUR,c.date.j,MOIS,c.date.m,ANNEE,c.date.a,VALMIN,c.valmin,VALMAX,c.valmax,ETAT,c.etat,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}


void chercher_capteur(capt rc)
{

capt c;
FILE *f=NULL;
    FILE *ft=NULL;
	remove("recherche.txt");
    f=fopen("capteurs.txt","r");
    ft=fopen("recherche.txt","a+");
    if ((f!=NULL)&&(ft!=NULL))
    {
     while(fscanf(f,"%s %s %s %s %d %d %d %s %s %d",c.refe,c.marque,c.type,c.prix,&c.date.j,&c.date.m,&c.date.a,c.valmin,c.valmax,&c.etat)!=EOF)
    {	
        if ( strcmp(rc.type, c.type)==0)
        {
       
	fprintf(ft,"%s %s %s %s %d %d %d %s %s %d\n",c.refe,c.marque,c.type,c.prix,c.date.j,c.date.m,c.date.a,c.valmin,c.valmax,c.etat);
        }

    }
        fclose(f);
        fclose(ft);
        
       
        }
        else
    {
      printf("impossible d'ouvrir le fichier");
    }
    }


void afficher_capteur_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	capt c;
	char refe[30];
	char marque[30];
	char type[30];
	char prix[30];
	char valmin[30];
	char valmax[30];
	int etat;
	int jour;
	int mois;
	int annee;

	
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("refe",renderer, "text",REFE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("marque",renderer, "text",MARQUE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer, "text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer, "text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("valmin",renderer, "text",VALMIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("valmax",renderer, "text",VALMAX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer, "text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer, "text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer, "text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer, "text",ETAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

f=fopen("recherche.txt","r");
if(f==NULL)
{
return;
}
else

{f=fopen("recherche.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %d",c.refe,c.marque,c.type,c.prix,&c.date.j,&c.date.m,&c.date.a,c.valmin,c.valmax,&c.etat)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,REFE,c.refe,MARQUE,c.marque,TYPE,c.type,PRIX,c.prix,JOUR,c.date.j,MOIS,c.date.m,ANNEE,c.date.a,VALMIN,c.valmin,VALMAX,c.valmax,ETAT,c.etat,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

int modifier(capt m)
{
capt c;	
FILE*f;
FILE*f1;
f=fopen("capteurs.txt","r");
f1=fopen("modifier.txt","w");

if ((f!=NULL) && (f1!=NULL))
    {
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %d",c.refe,c.marque,c.type,c.prix,&c.date.j,&c.date.m,&c.date.a,c.valmin,c.valmax,&c.etat)!=EOF)
    {
if(strcmp(c.refe,m.refe)!=0)
    {
fprintf(f1,"%s %s %s %s %d %d %d %s %s %d\n",c.refe,c.marque,c.type,c.prix,c.date.j,c.date.m,c.date.a,c.valmin,c.valmax,c.etat);
    }
else
    {

fprintf(f1,"%s %s %s %s %d %d %d %s %s %d\n",c.refe,m.marque,c.type,c.prix,c.date.j,c.date.m,c.date.a,m.valmin,m.valmax,m.etat);
    }
    }
fclose(f);
fclose(f1);

remove("capteurs.txt");
rename("modifier.txt","capteurs.txt");
return 1;
}        
}


int verifier(char vrefe[30])
{
int t=0;
capt c;
FILE *f=NULL;
    f=fopen("capteurs.txt","r");

    if (f!=NULL)
    {
     while(fscanf(f,"%s %s %s %s %d %d %d %s %s %d",c.refe,c.marque,c.type,c.prix,&c.date.j,&c.date.m,&c.date.a,c.valmin,c.valmax,&c.etat)!=EOF)
    {	
        if ( strcmp(vrefe,c.refe)==0)
        {
       t=1;
	
        }

         }
    
    }return t;
}

