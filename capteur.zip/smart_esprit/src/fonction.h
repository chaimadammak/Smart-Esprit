
#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
typedef struct date
{
int j,m,a;

}date;
typedef struct capt
{
    char refe[30];
    char marque[30];
    char type[30];
    date date;
    char prix[30];
    char valmin[30];
    char valmax[30];
    int etat;
}capt;

typedef struct defectueux
{
int tjour;
int theure;
int tnum;
float temperature;


}defectueux; 


void afficher_capteur_chercher(GtkWidget *liste);
void chercher_capteur(capt rc);
void supprimer(char srefe[]);
void ajouter(c);
void afficher_capteur(GtkWidget *liste);
int modifier(capt m);

int verifier(char vrefe[30]);



//void defectueux();




#endif //  FONCTION_H_INCLUDED

