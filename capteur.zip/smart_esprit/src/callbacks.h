#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_hs_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_es_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimer_cap_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actuliser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_rech_modif_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_modif_hs_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif_es_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_aff_defc_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
