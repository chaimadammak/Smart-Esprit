#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"projet.h"
#include "interface.h"
#include "callbacks.h"
#include "support.h"
#include <gtk/gtk.h>
utulisateur u;



/*void ajouter_utulisateur(utulisateur u){

    FILE* f=NULL;

    f=fopen("utulisateur.txt","a");

    fprintf(f,"%s %s %s %s %s %d %d %d %d %d/n",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
    fclose(f);

}*/
int verif(char identifiant[])
{
    int test=0;
    FILE*f=NULL;
    utulisateur u;
    f=fopen("utulisateur.txt","r");
    while ((fscanf(f,"%s %s %s %s %s %d %d %d %d %d",u.nom,u.prenom,u.identifiant,u.password,u.role,&u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,&u.origine)!=EOF)&&(test==0)){
            if(strcmp(identifiant,u.identifiant)==0)
            {
                test=1;
            }

    }
    return test;
} 
void supprimer_utulisateur(char identifiant[]){





    FILE*f=NULL;
    FILE*f1=NULL;
    utulisateur u ;
    int test=1;
    f=fopen("utulisateur.txt","r");
    f1=fopen("ancien.txt","w+");
    while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,u.origine)!=EOF){
        if(strcmp(identifiant,u.identifiant)!=0)
            fprintf(f1,"%s %s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
    }
    fclose(f);
    fclose(f1);
    remove("utulisateur.txt");
    rename("ancien.txt","utulisateur.txt");
} 
/*
void modifer_utulisateur(char identifiant [] ,char new_password [], char new_role[]){
    FILE*f=NULL;
    FILE*f1=NULL;
    utulisateur u ;
    f=fopen("utulisateur.txt","r");

    f1=fopen("ancien.txt","w+");
    while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,u.origine)!=EOF){
        if( strcmp(identifiant,u.identifiant)!=0)
        {
            fprintf(f1,"%s %s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
        }
        else
        {
            fprintf(f1,"%s %s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.identifiant,new_password,new_role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
        }

    }
    fclose(f);
    fclose(f1);

    remove("utulisateur.txt");
    rename("ancien.txt","utulisateur.txt");
}*/
void modifer_utulisateur(char identifiant [] ,utulisateur u1){
    FILE*f=NULL;
    FILE*f1=NULL;
    utulisateur u ;
    f=fopen("utulisateur.txt","r");

    f1=fopen("ancien.txt","w");
    while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,u.origine)!=EOF){
        if( strcmp(identifiant,u.identifiant)!=0)
        {
            fprintf(f1,"%s %s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
        }
        else
        {
            fprintf(f1,"%s %s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.identifiant,u1.password,u1.role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
        }

    }
    fclose(f);
    fclose(f1);

    remove("utulisateur.txt");
    rename("ancien.txt","utulisateur.txt");
}
void recherche_utulisateur(char nom []){
    FILE*f=NULL;
    FILE*f1=NULL;
    utulisateur u;
    f=fopen("utulisateur.txt","r");
    f1=fopen("recherche_nom.txt","a");
     while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,u.origine)!=EOF){
        if(strcmp(nom,u.nom)==0)
            fprintf(f1,"%s %s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,u.d.jour,u.d.mois,u.d.annee,u.origine);
     }
     fclose(f);
     fclose(f1);


} 
enum {
ENOM,
EPRENOM,
EID,
EPASSWORD,
EROLE,
ESEXE,
EJOUR,
EMOIS,
EANNEE,
EORIGINE,
COLUMNS
};
enum {
ejour,
eheure,
eenum,
eval,
columns
};
void afficher(GtkWidget *liste) {
    
    FILE*f ;
    utulisateur u;
    GtkCellRenderer *renderer; 
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    
     store=NULL;
	
     store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{	renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("prenom",renderer,"text",EPRENOM,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("identifiant",renderer,"text",EID,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("password",renderer,"text",EPASSWORD,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("role",renderer,"text",EROLE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("sexe",renderer,"text",ESEXE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		column=gtk_tree_view_column_new_with_attributes     ("jour",renderer,"text",EJOUR,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("mois",renderer,"text",EMOIS,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("annee",renderer,"text",EANNEE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("origine",renderer,"text",EORIGINE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		}
    		store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
		f=fopen("utulisateur.txt","r");
                if(f==NULL) {
		printf("erreur");
 		}
 	
		else {
			f=fopen("utulisateur.txt","a+");
			 while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,u.origine)!=EOF){
    				gtk_list_store_append (store,&iter);					   	gtk_list_store_set(store,&iter,ENOM,u.nom,EPRENOM,u.prenom,EID,u.identifiant,EPASSWORD,u.password,EROLE,u.role,ESEXE,u.sexe,EJOUR,u.d.jour,EMOIS,u.d.mois,EANNEE,u.d.annee,EORIGINE,u.origine,-1); 

     			}
			fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
			}
}
void afficher_nom(GtkWidget *liste) {
FILE*f ;
    utulisateur u;
    GtkCellRenderer *renderer; 
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    
     store=NULL;
	
     store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{	renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("prenom",renderer,"text",EPRENOM,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("identifiant",renderer,"text",EID,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("password",renderer,"text",EPASSWORD,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("role",renderer,"text",EROLE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("sexe",renderer,"text",ESEXE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		column=gtk_tree_view_column_new_with_attributes     ("jour",renderer,"text",EJOUR,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("mois",renderer,"text",EMOIS,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("annee",renderer,"text",EANNEE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("origine",renderer,"text",EORIGINE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		}
    		store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
		f=fopen("utulisateur.txt","r");
                if(f==NULL) {
		printf("erreur");
 		}
 	
		else {
			f=fopen("recherche_nom.txt","a+");
			 while(fscanf(f,"%s %s %s %s %s %s %d %d %d %s",u.nom,u.prenom,u.identifiant,u.password,u.role,u.sexe,&u.d.jour,&u.d.mois,&u.d.annee,u.origine)!=EOF){
    				gtk_list_store_append (store,&iter);					   	gtk_list_store_set(store,&iter,ENOM,u.nom,EPRENOM,u.prenom,EID,u.identifiant,EPASSWORD,u.password,EROLE,u.role,ESEXE,u.sexe,EJOUR,u.d.jour,EMOIS,u.d.mois,EANNEE,u.d.annee,EORIGINE,u.origine,-1); 

     			}
			fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
			}
}
void vider (GtkWidget*liste){
     FILE*f ;
    utulisateur u;
    GtkCellRenderer *renderer; 
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    store=NULL;
	
     store=gtk_tree_view_get_model(liste);
    
    if(store==NULL)
	{	renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",ENOM,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("prenom",renderer,"text",EPRENOM,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("identifiant",renderer,"text",EID,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes ("password",renderer,"text",EPASSWORD,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("role",renderer,"text",EROLE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("sexe",renderer,"text",ESEXE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		column=gtk_tree_view_column_new_with_attributes     ("jour",renderer,"text",EJOUR,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("mois",renderer,"text",EMOIS,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("annee",renderer,"text",EANNEE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

    		renderer=gtk_cell_renderer_text_new ();
    		column=gtk_tree_view_column_new_with_attributes     ("origine",renderer,"text",EORIGINE,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		}
    store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
    gtk_list_store_append (store,&iter);	
    gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
}

			  
void dashbord () {
    FILE*f=NULL;
    FILE*f1=NULL;
    FILE*f2=NULL;
    alarmes A;
    f=fopen("fumee.txt","r");
    f2=fopen("alarmes.txt","a");
    if (f!=NULL) {
    	while(fscanf(f,"%s %s %s %s", A.jour,A.heure,A.num,A.val)!=EOF) { //verif heure
        	if ((atoi(A.val)==1)&&(0<(atoi(A.heure)<6)))
           		 fprintf(f2,"%s %s %s %s\n",A.jour,A.heure,A.num,A.val);
    	}
    }
    fclose(f);
    fclose(f2);
    f1=fopen("movement.txt","r");
    f2=fopen("alarmes.txt","a");
    if (f1!=NULL) {
    	while (fscanf(f1,"%s %s %s %s",A.jour,A.heure,A.num,A.val)!=EOF) {
        	if((atoi(A.val)==1)&&(0<(atoi(A.heure)<6)))
            		fprintf(f2,"%s %s %s %s\n",A.jour,A.heure,A.num,A.val);
        }
    }
    fclose(f1);
    fclose(f2);

} 


void afficher_dashbord(GtkWidget *liste) {
	FILE*f ;
	alarmes A;
	GtkCellRenderer *renderer; 
    	GtkTreeViewColumn *column;
    	GtkTreeIter iter;
    	GtkListStore *store;
	store=NULL;
	
     	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{	renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",ejour,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("heure",renderer,"text",eheure,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("num",renderer,"text",eenum,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer=gtk_cell_renderer_text_new ();
                column=gtk_tree_view_column_new_with_attributes ("val",renderer,"text",eval,NULL);
    		gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	}
	store=gtk_list_store_new (columns,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("alarmes.txt","r");
                if(f==NULL) {
		printf("erreur");
 		}
		else {
			f=fopen("alarmes.txt","a+");
			while (fscanf(f,"%s %s %s %s",A.jour,A.heure,A.num,A.val)!=EOF) {
				gtk_list_store_append (store,&iter);
				gtk_list_store_set(store,&iter,ejour,A.jour,eheure,A.heure,eenum,A.num,eval,A.val,-1);
			}
			fclose(f);
			gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
			g_object_unref(store);
		}
}


