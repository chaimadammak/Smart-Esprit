#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include "projet.h"



int sexe;
int origine;
FILE *f=NULL;
void
on_radiobuttonhomme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
sexe=1;
}


void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
sexe=0;
}


void
on_checkbuttontun_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
origine=1;
}


void
on_checkbuttonetranger_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
origine=0;
}


void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
int test;
char texte2[30]="";
char texte1[30]="";
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labelid;
GtkWidget *labelmot;
GtkWidget *entry1;
GtkWidget *entry2;
GtkWidget *entry3;
GtkWidget *entrymot;
GtkWidget *labeljour;
GtkWidget *labelmois;
GtkWidget *labelannee;
GtkWidget *spinbuttonjour;
GtkWidget *spinbutton2;
GtkWidget *spinbutton3;
GtkWidget *labelrole;
GtkWidget *radiobuttonhomme;
GtkWidget *radiobuttonfemme;
GtkWidget *checkbuttontun;
GtkWidget *checkbuttonetranger;
GtkWidget *combobox1;
GtkWidget *labelsexe;
GtkWidget *label27;
GtkWidget* output;
GtkWidget *label_mesj_ajout;
GtkWidget* output2;
labelnom=lookup_widget(button,"entry1");
labelprenom=lookup_widget(button,"entry2");
labelid=lookup_widget(button,"entry3");
labelmot=lookup_widget(button,"entrymot");
labeljour=lookup_widget(button,"spinbuttonjour");
labelmois=lookup_widget(button,"spinbutton2");
labelannee=lookup_widget(button,"spinbutton3");
combobox1=lookup_widget(button,"combobox1");
char nom [20];
char prenom [20];
char identifiant[20];
char password[20];
char sexee[20];
char originee[20];
int jour;
int mois;
int annee;
char role[20];
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(labelnom)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(labelprenom)));
strcpy(identifiant,gtk_entry_get_text(GTK_ENTRY(labelid)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(labelmot)));

// ecrire le sexe
if (sexe==1)
{
    strcpy(sexee,"homme");
}
if(sexe==0)
{
    strcpy(sexee,"femme");
}

//ecrire l origine
if (origine==1)
{
    strcpy(originee,"tunisien");
}
if(origine==0)
{
    strcpy(originee,"etranger");
}
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(labeljour));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(labelmois));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(labelannee));
if(strcmp("Nutrioniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)  
                 {
                     strcpy(role,"Nutrioniste");
                 }
                 
                if(strcmp("Admin",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0) 
                {
                     strcpy(role,"Admin");
                }
                if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0) 
                {
                    strcpy(role,"Technicien");
                    
                }
                if(strcmp("Agent de foyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
                {
                    strcpy(role,"Agent de foyer");
                }
                 if(strcmp("Agent de restaurant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
                 {
                    strcpy(role,"Agent de restaurant");
                 }
                 
                if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
                {
                   strcpy(role,"Etudiant");
                }
f=fopen("utulisateur.txt","a+");
test=verif(identifiant);
if((f!=NULL)&&(test==0))
{
fprintf(f,"%s %s %s %s %s %s %d %d %d %s\n",nom,prenom,identifiant,password,role,sexee,jour,mois,annee,originee);
fclose(f);
sprintf(texte1,"Ajout fait avec succées");
output2=lookup_widget(button, "label_mesj_ajout");
gtk_label_set_text(GTK_LABEL(output2),texte1);
}
else {
printf("\n Not found");
sprintf(texte2,"Identifiant existe déjà!");
output=lookup_widget(button, "label27");
gtk_label_set_text(GTK_LABEL(output),texte2);
}
}


void
on_treeviewrech_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_buttonrech_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewrech;

treeviewrech=lookup_widget(objet,"treeviewrech");
afficher(treeviewrech);

}


void
on_treeviewmodif_supp_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{utulisateur u;
GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* identifiant;
gchar* password;
gchar* role;
gchar* sexe;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* origine;
	gint* jo;
	gint* mo;
	gint* an;
	jo=u.d.jour;
	mo=u.d.mois;
	an=u.d.annee;
GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path)) {
	//obtention des valeurs de la ligne selectionnée
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&identifiant,3,&password,4,&role,5,&sexe,6,&jour,7,&mois,8,&annee,9,&origine,-1);
	//copie des valeurs dans la variable u de type utulisateur pour le passer a la fonction de suppression 
	strcpy(u.nom,nom);
	strcpy(u.prenom,prenom);
	strcpy(u.identifiant,identifiant);
	strcpy(u.password,password);
	strcpy(u.role,role);

	strcpy(u.origine,origine);

	jo = jour;
	mo = mois;
	an = annee ; 
	//appel al la fonction de suppression 
	 supprimer_utulisateur(identifiant);
	 afficher(treeview);

	}
	
	
}


void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char texte3[30]="";
char texte4[30]="";
int test=0;
utulisateur u1;
GtkWidget *input1,*input2;
GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget *treeview2;
GtkWidget* output3;
GtkWidget* output4;
gchar *id;
treeview2=lookup_widget(button,"treeview2");
input1=lookup_widget(button,"entrynouvmot");
input2=lookup_widget(button,"entrynouvrole");
strcpy(u1.password,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(u1.role,gtk_entry_get_text(GTK_ENTRY(input2)));
if (strcmp("Admin",u1.role)==0)
  test=1;
else if(strcmp("Nutrioniste",u1.role)==0) 
  test=1;
else if (strcmp("Agent de foyer",u1.role)==0)
  test=1;
else if (strcmp("Agent de restaurant",u1.role)==0)
  test=1;
else if (strcmp("Technicien",u1.role)==0)
  test=1;
else if (strcmp("Etudiant",u1.role)==0)
  test=1;
selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview2));
if(gtk_tree_selection_get_selected(selection,&model,&iter)&&(test==1)) {
gtk_tree_model_get(model,&iter,2,&id,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
modifer_utulisateur(id,u1); 
}
else {
sprintf(texte4,"Role n'existe pas !");
output4=lookup_widget(button, "label34_mesjrole");
gtk_label_set_text(GTK_LABEL(output4),texte4);
}

}


void
on_buttonsupp_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{/*
utulisateur u;
GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget *treeviewmodif_supp;
gchar *identifiant;
treeviewmodif_supp=lookup_widget(objet,"treeviewmodif_supp");
selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(treeviewmodif_supp));
if(gtk_tree_selection_get_selected(selection,&model,&iter)) {
gtk_tree_model_get(model,&iter,0,&identifiant,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
	 supprimer_utulisateur(identifiant);
}*/
}


void
on_buttonvalider_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeviewdashbord_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeviewmodif_supp;
treeviewmodif_supp=lookup_widget(button,"treeviewmodif_supp");
afficher(treeviewmodif_supp);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *treeview1;
GtkWidget *nomcherch;
char nom[20];
FILE *f;
nomcherch=  lookup_widget(button, "entrynomrech");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(nomcherch)));
recherche_utulisateur(nom);
treeview1=lookup_widget(button,"treeview1");
afficher_nom(treeview1);
}
void
on_button4_chercher_activate           (GtkWidget       *objet,
                                        gpointer         user_data)
{



}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
treeview2=lookup_widget(button,"treeview2");
afficher(treeview2);
}


void
on_Actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1 ,*w1;
GtkWidget *treeviewrech; //a remplacer par nom du treeview
w1=lookup_widget(button,"window1"); //a remplacer par window1 
window1=create_window1();
gtk_widget_show(window1);
gtk_widget_hide(w1);
treeviewrech=lookup_widget(window1,"treeviewrech");
vider(treeviewrech);
afficher(treeviewrech);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
remove("recherche_nom.txt");
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeviewdashbord;
treeviewdashbord=lookup_widget(button,"treeviewdashbord");
dashbord();
afficher_dashbord(treeviewdashbord);
}


void
on_instagram_chaima_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox http://www.instagram.com");
}


void
on_facebook_chaima_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
system("firefox http://www.facebook.com");
}

