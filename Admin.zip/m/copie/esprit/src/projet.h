

#ifndef PROJET_H_INCLUDED
#define PROJET_H_INCLUDED
#include<gtk/gtk.h>
typedef struct{
int jour;
int mois;
int annee ;
}date;
/*typedef struct {
   char jour[20] ;
   char  heure[20];
   char num[20];
   char val[20];



} fumee;
typedef struct {
    char jour[20] ;
    char heure[20];
    char num[20];
    char val[20];

} mvt; */
typedef struct {
   char jour[20] ;
   char heure[20];
   char num[20];
   char val[20];
} alarmes;
typedef struct{
char nom [20];
char prenom [20];
char identifiant[20];
char password[20];
char role[20];
date d;
char sexe[20];
char origine[20];

}utulisateur;


//void ajouter_utulisateur(utulisateur u);
int verif(char identifiant []);
void supprimer_utulisateur(char identifiant[]);
void modifer_utulisateur(char identifiant[],utulisateur u1);
void recherche_utulisateur(char nom []);
void afficher(GtkWidget *liste);
void afficher_nom(GtkWidget *liste);
void vider (GtkWidget*liste);
void dashbord () ;
void afficher_dashbord(GtkWidget *liste);
#endif // PROJET_H_INCLUDED



