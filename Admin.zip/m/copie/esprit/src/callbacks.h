#include <gtk/gtk.h>


void
on_radiobuttonhomme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttontun_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonetranger_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewrech_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_treeviewmodif_supp_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewdashbord_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_instagram_chaima_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_facebook_chaima_clicked             (GtkButton       *button,
                                        gpointer         user_data);
